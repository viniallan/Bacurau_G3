//********************************************************//
//File name: Encoder.h
//File description: 
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 12/05/23
//Revision Date: 18/05/23
//********************************************************//

#ifndef INC_Encoder_H_
#define INC_Encoder_H_



#endif /* INC_Encoder_H_ */

extern unsigned short int usiCoolerSpeed;

// ***************************************************** //
//Method Name: vEncoderInit
//Method Description: Initialize timer 3 and 4 in order to
//count timer 3 rising edges.Does the counter of both
//as a zero.
//
//Input Params: unsigned int uiPeriod
//
//OutPut Params: n/a
// ***************************************************** //
void vEncoderInit(unsigned int uiPeriod);

// ***************************************************** //
//Method Name: vEncoderUpdate
//Method Description: this functions does the math to converte
//the counted number and period to RPM
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vEncoderUpdate();

// ***************************************************** //
//Method Name: vEncoderCallback
//Method Description: Callback to handle fixed window.Call
//the update function each time that timer4 shout and
//does the counters as a zero.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vEncoderCallback();

// ***************************************************** //
//Method Name: vEncoderGetFrequency
//Method Description: Return frequency of the Encoder that
//is in global place.
//
//Input Params: n/a
//
//OutPut Params: unsigned short int usiCoolerSpeed
// ***************************************************** //
unsigned short int vEncoderGetFrequency();
