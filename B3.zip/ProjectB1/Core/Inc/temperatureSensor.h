//********************************************************//
//File name: temperatureSensor.c
//File description: This file implements the conversion from a
//sensor witch return a value in int and we transform to analogic
//The objective is read a engineer value, not a computer value
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 19/05/23
//Revision Date: 25/05/23
//********************************************************//
#ifndef INC_TEMPERATURESENSOR_H_
#define INC_TEMPERATURESENSOR_H_



#endif /* INC_TEMPERATURESENSOR_H_ */

#include "adc.h"

// ***************************************************** //
//Method Name: vTemperatureSensorInit
//Method Description: this function sets the calibration
//of the adc and starts the DMA process
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vTemperatureSensorInit(ADC_HandleTypeDef *hadc);

// ***************************************************** //
//Method Name: fTemperatureSensorGetTemperature
//Method Description: this function returns a value in float
//that is the currently temperature of the sensor
//
//Input Params: n/a
//
//OutPut Params:float fMyTensao
// ***************************************************** //
float fTemperatureSensorGetTemperature();
