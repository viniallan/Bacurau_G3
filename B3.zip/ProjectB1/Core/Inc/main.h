/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern unsigned char c;
extern unsigned int uiValueFromDMA;
extern float fResistanceCurrently;
extern float fResistanceSet;
/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void vMainInitAll();

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define B1_EXTI_IRQn EXTI15_10_IRQn
#define LPUART1_TX_Pin GPIO_PIN_2
#define LPUART1_TX_GPIO_Port GPIOA
#define LPUART1_RX_Pin GPIO_PIN_3
#define LPUART1_RX_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define T_SWDIO_Pin GPIO_PIN_13
#define T_SWDIO_GPIO_Port GPIOA
#define T_SWCLK_Pin GPIO_PIN_14
#define T_SWCLK_GPIO_Port GPIOA
#define T_SWO_Pin GPIO_PIN_3
#define T_SWO_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */


#define Col4_Pin GPIO_PIN_7
#define Col4_GPIO_Port GPIOC
#define Col3_Pin GPIO_PIN_8
#define Col3_GPIO_Port GPIOC
#define Col2_Pin GPIO_PIN_9
#define Col2_GPIO_Port GPIOC
#define Col1_Pin GPIO_PIN_10
#define Col1_GPIO_Port GPIOA

#define Row4_Pin GPIO_PIN_11
#define Row4_GPIO_Port GPIOB
#define Row3_Pin GPIO_PIN_12
#define Row3_GPIO_Port GPIOB
#define Row2_Pin GPIO_PIN_13
#define Row2_GPIO_Port GPIOB
#define Row1_Pin GPIO_PIN_15
#define Row1_GPIO_Port GPIOB

#define Btn_Up_Pin GPIO_PIN_1
#define Btn_Up_GPIO_Port GPIOC
#define Btn_Down_Pin GPIO_PIN_2
#define Btn_Down_GPIO_Port GPIOC
#define Btn_Left_Pin GPIO_PIN_3
#define Btn_Left_GPIO_Port GPIOC
#define Btn_Right_Pin GPIO_PIN_4
#define Btn_Right_GPIO_Port GPIOC
#define Btn_Enter_Pin GPIO_PIN_0
#define Btn_Enter_GPIO_Port GPIOB

#define TRUE 1
#define FALSE 0
#define MAX_TEMP 90

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
