/*
 * states.h
 *
 *  Created on: 14 de jun de 2023
 *      Author: aluno
 */

#ifndef INC_STATES_H_
#define INC_STATES_H_



#endif /* INC_STATES_H_ */

#define STATEKP 0
#define STATEKI 1
#define STATEKD 2
#define STATECOOLERSPEED 3
#define STATECURRENTLYSETPOINT	4
#define STATECURRENTLYDUTYCICLER 5

extern unsigned char ucState;
extern unsigned char ucStateGainButton;
extern int iTimer;

void vStatesLoop();

void vStatesTimerCallback();

void vStatesNextState();

int vStatesChangeGainButton();

unsigned char ucStatesReturnState();

unsigned char ucStatesReturnStateButtonGain();

void vStatesSetState(unsigned char ucNewState);

void vStatesCleanCounter();
