//********************************************************//
//File name: communication.h
//File description: This file implements the some functions
// 					to exchange date with the Putty Terminal
// 					there are some function that do the call 
//					back logic and function that does the
//  				comparation beetween the numbers limits
// 
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 23/04/23
//Revision Date: 27/04/23
//********************************************************//
#ifndef INC_COMMUNICATION_H_
#define INC_COMMUNICATION_H_



#endif /* INC_COMMUNICATION_H_ */

void vCommunicationCallback(char cVar);
int iCommunicationCheckBeetwen2ThousandReturnInverse(float ucNumber);
