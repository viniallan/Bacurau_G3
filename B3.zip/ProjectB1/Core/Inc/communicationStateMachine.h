//********************************************************//
//File name: communicationStateMachine.h
//File description: This file implements a state machine that 
//models the communication between computer and STM board. Creating
//a communication protocol.
//
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 28/04/23
//Revision Date: /04/23
//********************************************************//

#ifndef INC_COMMUNICATIONSTATEMACHINE_H_
#define INC_COMMUNICATIONSTATEMACHINE_H_

#endif /* INC_COMMUNICATIONSTATEMACHINE_H_ */


void vCommunicationStateMachineProcessByteCommunication(unsigned char ucByte);

void vCommunicationStateMachinePrintUcValue(unsigned char ucValue);

void vCommunicationStateMachinePrintFloatValue(float fValue);

void vCommunicationStateMachineReturnParam(unsigned char *ucParam);

void vCommunicationStateMachineSetParam(unsigned char *ucParam,unsigned char*  ucValue);

float fCommunicationStateMachineConvertStringToFloat(unsigned char *ucString);

unsigned char ucCommunicationStateMachineConvertUnsignedCharVectorToNumber(unsigned char *ucString);
