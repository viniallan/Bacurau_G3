//********************************************************//
//File name: heaterAndCooler.h
//File description: This file implements
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 12/05/23
//Revision Date: 16/05/23
//********************************************************//

#ifndef INC_HEATERANDCOOLER_H_
#define INC_HEATERANDCOOLER_H_

#endif /* INC_HEATERANDCOOLER_H_ */

extern uint32_t uiCurrentlyDutyCooler;
extern uint32_t uiCurrentlyDutyHeater;


// ***************************************************** //
//Method Name: vHeaterAndCoolerInit
//Method Description: Initialize pwm timers.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeaterAndCoolerInit();

// ***************************************************** //
//Method Name: vHeaterAndCoolerCoolerfanPWMDuty
//Method Description: Set cooler duty cycle.
//
//Input Params: float fCoolerDuty
//
//OutPut Params: n/a
// ***************************************************** //
void vHeaterAndCoolerCoolerfanPWMDuty(float fCoolerDuty);

// ***************************************************** //
//Method Name: vHeaterAndCoolerHeaterPWMDuty
//Method Description: Set Heater duty cycle.
//
//Input Params: float fHeaterDuty
//
//OutPut Params: n/a
// ***************************************************** //
void vHeaterAndCoolerHeaterPWMDuty(float fHeaterDuty);

// ***************************************************** //
//Method Name: vHeaterAndCoolerStopCooler
//Method Description: Stop cooler, set its duty cycle to zero.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeaterAndCoolerStopCooler();

// ***************************************************** //
//Method Name: vHeaterAndCoolerStopHeater
//Method Description: Stop heater, set its duty cycle to zero.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeaterAndCoolerStopHeater();

// ***************************************************** //
//Method Name: vHeadAndCoolerIncrise10DutyCooler
//Method Description: Increase cooler duty cycle.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeadAndCoolerIncrise10DutyCooler();

// ***************************************************** //
//Method Name: vHeadAndCoolerIncrise10DutyHeater
//Method Description: Increase heater duty cycle.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeadAndCoolerIncrise10DutyHeater();

// ***************************************************** //
//Method Name: vHeadAndCoolerDecrise10DutyCooler
//Method Description: Decrease cooler duty cycle.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeadAndCoolerDecrise10DutyCooler();

// ***************************************************** //
//Method Name: vHeadAndCoolerDecrise10DutyHeater
//Method Description: Decrease heater duty cycle.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vHeadAndCoolerDecrise10DutyHeater();
