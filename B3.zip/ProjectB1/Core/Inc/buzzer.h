//********************************************************//
//File name: buzzer.h
//File description: This file implements 
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 12/05/23
//Revision Date: 16/05/23
//********************************************************//

#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_



#endif /* INC_BUZZER_H_ */

// ***************************************************** //
//Method Name: vBuzzerInit
//Method Description: Initialize the buzzer pwm timer and counter.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vBuzzerInit();


// ***************************************************** //
//Method Name: vBuzzerConfig
//Method Description: Set buzzer frequency and period.
//
//Input Params: unsigned short int usiFrequency, unsigned short int usiPeriod
//
//OutPut Params: n/a
// ***************************************************** //
void vBuzzerConfig(unsigned short int usiFrequency, unsigned short int usiPeriod);

// ***************************************************** //
//Method Name: vBuzzerPlay
//Method Description: Play buzzer.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vBuzzerPlay();

// ***************************************************** //
//Method Name: vBuzzerCallback
//Method Description: Deals with the buzzer interuption.
//
//Input Params: n/a
//
//OutPut Params: n/a
// ***************************************************** //
void vBuzzerCallback();
