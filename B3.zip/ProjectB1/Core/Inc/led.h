//*********************************************
//File name: led.c
//File description: This file implements the basic
//configuration to make all leds available
//there are functions to set and reset led
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 24/03/23
//Revision Date: 03/04/23
//**********************************************

#ifndef INC_LED_H_
#define INC_LED_H_

#endif /* INC_LED_H_ */

enum xEnumLeds{green1=1,yellow=2,red=3,green2=4,blue=5};

void vLedInitLeds();

void vLedConfigLed(int xLeds,int iValueConfig);

void vLedSetLed(int xLeds);

void vLedResetLed(int xLeds);

void vLedToggleLed(int xLeds);
