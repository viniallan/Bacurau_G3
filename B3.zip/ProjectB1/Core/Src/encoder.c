//********************************************************//
//File name: Encoder.c
//File description: This file implements the Encoder handler.

#include "main.h"
#include "tim.h"
#include "encoder.h"

unsigned int uiPeriodWindow;
unsigned short int usiCoolerSpeed;

void vEncoderInit(){
	// ***************************************************** //
	//Method Name: vEncoderInit
	//Method Description: Initialize timer 3 and 4 in order to 
	//count timer 3 rising edges.Does the counter of both
	//as a zero.
	//
	//Input Params: unsigned int uiPeriod
	//
	//OutPut Params: n/a
	// ***************************************************** //

	TIM16->CNT=0;

	HAL_TIM_Base_Start_IT(&htim16);
}


void vEncoderCallback(){
	// ***************************************************** //
	//Method Name: vEncoderCallback
	//Method Description: Callback to handle fixed window.Call
	//the update function each time that timer4 shout and
	//does the counters as a zero.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	vEncoderUpdate();
	TIM16->CNT=0;

}

void vEncoderUpdate(){
	// ***************************************************** //
	//Method Name: vEncoderUpdate
	//Method Description: this functions does the math to converte
	//the counted number and period to RPM
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	uint32_t uiCounted=TIM16->CNT;
	usiCoolerSpeed=(unsigned short int)fSpeedAux;
}


unsigned short int vEncoderGetFrequency(){
	// ***************************************************** //
	//Method Name: vEncoderGetFrequency
	//Method Description: Return frequency of the Encoder that
	//is in global place.
	//
	//Input Params: n/a
	//
	//OutPut Params: unsigned short int usiCoolerSpeed
	// ***************************************************** //
	return usiCoolerSpeed;
}
