//********************************************************//
//File name: led.c
//File description: This file implements the basic
//configuration to make all leds available
//there are functions to set and reset led
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 24/03/23
//Revision Date: 03/04/23
//********************************************************//

#include "led.h"
#include "main.h"

void vLedInitLeds(){
	// ***************************************************** //
	//Method Name: 	vLedInitLeds
	//Method Description: this method aims to initilize the clock
	// and the configuration moder and typer of each led.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //

	//Clock
	RCC->AHB2ENR |= 0x00000001; //Clock liberado porta A
	RCC->AHB2ENR |= 0x00000002; //Clock liberado porta B

	//Green LED
	GPIOA->MODER |= 0x00000400; //0100 0000 0000 -> Colocando 1 no MODE5(0)
	GPIOA->MODER &= ~0x00000800;//1000 0000 0000 -> Colocando 0 no MODE5(1)
	GPIOA->OTYPER &= ~0x00000020;//0010 0000 -> Colocando 0 no OT5


	//Yellow LED
	GPIOA->MODER |= 0x00000100; //0001 0000 0000 -> Colocando 1 no MODE4(0)
	GPIOA->MODER &= ~0x00000200;//0010 0000 0000 -> Colocando 0 no MODE4(1)
	GPIOA->OTYPER &= ~0x00000010;//0001 0000 -> Colocando 0 no OT4


    //Red LED
	GPIOB->MODER |= 0x10000000;
	GPIOB->MODER &= ~0x20000000;
	GPIOB->OTYPER &= ~0x00004000;

	//Green 2 PWM LED
	GPIOA->MODER |= 0x01000000;//0000 0001 0000 0000 0000 0000 0000 0000
	GPIOA->MODER &= ~0x02000000;//0000 0010 0000 0000 0000 0000 0000 0000
	GPIOA->OTYPER &= ~0x00001000;//0000 0000 0000 0000 0001 0000 0000 0000

	//Blue LED
	GPIOB->MODER |= 0x00000400; //0100 0000 0000
	GPIOB->MODER &= ~0x00000800;//1000 0000 0000
	GPIOB->OTYPER &= ~0x00000020;//0010 0000

}

void vLedConfigLed(int xLeds, int iValueConfig){
	// ***************************************************** //
	//Method Name: 	vLedConfigLed
	//
	//Method Description: this method aims to set or reset the led
	// based on the value of the variable iValueConfig. If the variable
	//were 0, the led will be low ,if were 1, will be high.
	//
	//Input Params: xLeds-the number that is conected to the Led.
	//				iValueConfig-value that will set or reset the led.
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(xLeds==1){
		//green1
		if(iValueConfig==1){
			GPIOA->ODR |= 0x00000020;	//0010 0000
		}
		else if(iValueConfig==0){
			GPIOA->ODR &= ~0x00000020;	//0010 0000
		}
		else{
			//empty
		}
	}
	else if(xLeds==2){
		//yellow
		if(iValueConfig==1){
			GPIOA->ODR |= 0x00000010; //0001 0000
		}
		else if(iValueConfig==0){
			GPIOA->ODR &= ~0x00000010; //0001 0000
		}
		else{
			//empty
		}
	}
	else if(xLeds==3){
		//Red
		if(iValueConfig==1){
			GPIOB->ODR |= 0x00004000; //0100 0000 0000 0000
		}
		else if(iValueConfig==0){
			GPIOB->ODR &= ~0x00004000; //0100 0000 0000 0000
		}
		else{

		}
	}
	else if(xLeds==4){
		//green 2
		if(iValueConfig==1){
			GPIOA->ODR |= 0x00001000;//0000 0000 0000 0000 0001 0000 0000 0000
		}
		else if(iValueConfig==0){
			GPIOA->ODR &= ~0x00001000;//0000 0000 0000 0000 0001 0000 0000 0000
		}
		else{
			//empty
		}
	}
	else if(xLeds==5){
		//blue
		if(iValueConfig==1){
			GPIOB->ODR |= 0x00000020;	//0010 0000
		}
		else if(iValueConfig==0){
			GPIOB->ODR &= ~0x00000020;	//0010 0000
		}
		else{
			//empty
		}
	}
}

void vLedSetLed(int xLeds){
	// ***************************************************** //
	//Method Name: 	vLedSetLed
	//
	//Method Description: this method aims to set the led
	// We just neet do give the number of the Led that we want
	//to be high
	//
	//Input Params: xLeds-the number that is conected to the Led.
	//
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(xLeds==1){
		GPIOA->ODR |= 0x00000020;	//0010 0000
	}
	else if(xLeds==2){
		GPIOA->ODR |= 0x00000010; //0001 0000
	}
	else if(xLeds==3){
		GPIOB->ODR |= 0x00004000;
	}
	else if(xLeds==4){
		GPIOA->ODR |= 0x00001000;//0000 0000 0000 0000 0001 0000 0000 0000
	}
	else if(xLeds==5){
		GPIOB->ODR |= 0x00000020;	//0010 0000
	}
	else{
		//empty
	}
}

void vLedResetLed(int xLeds){
	// ***************************************************** //
	//Method Name: 	vLedResetLed
	//
	//Method Description: this method aims to Reset the led
	// We just neet do give the number of the Led that we want
	//to be Low
	//
	//Input Params: xLeds-the number that is conected to the Led.
	//
	//
	//OutPut Params: n/a
	if(xLeds==1){
		GPIOA->ODR &= ~0x00000020;	//0010 0000
	}
	else if(xLeds==2){
		GPIOA->ODR &=  ~0x00000010; //0001 0000
	}
	else if(xLeds==3){
		GPIOB->ODR &= ~0x00004000;
	}
	else if(xLeds==4){
		GPIOA->ODR &= ~0x00001000;//0000 0000 0000 0000 0001 0000 0000 0000
	}
	else if(xLeds==5){
		GPIOB->ODR &= ~0x00000020;	//0010 0000
	}
	else{
		//empty
	}
}

void vLedToggleLed (int xLeds){
	// ***************************************************** //
	//Method Name: 	vLedToggleLed
	//
	//Method Description: this method aims to change the Led
	// We just neet do give the number of the Led that we want
	//to be change. If it was in low, it will to high, and if it was
	//in high, it'll to low.
	//
	//Input Params: xLeds-the number that is conected to the Led.
	//
	//
	//OutPut Params: n/a
	if(xLeds==1){
		if((GPIOA->ODR >>5) & 1){
			vLedResetLed(1);
		}
		else{
			vLedSetLed(1);
		}
	}
	else if(xLeds==2){
		if((GPIOA->ODR >>4) & 1){
			vLedResetLed(2);
		}
		else{
			vLedSetLed(2);
		}
	}
	else if(xLeds==3){
		if((GPIOB->ODR >>14) & 1){
			vLedResetLed(3);
		}
		else{
			vLedSetLed(3);
		}
	}
	else if(xLeds==4){
		if((GPIOA->ODR >>12) & 1){
			vLedResetLed(4);
		}
		else{
			vLedSetLed(4);
		}
	}
	else if(xLeds==5){
		if((GPIOB->ODR >>5) & 1){
			vLedResetLed(5);
		}
		else{
			vLedSetLed(5);
		}
	}
	else{
		//Empty
	}
}

