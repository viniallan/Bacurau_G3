//********************************************************//
//File name: temperatureSensor.c
//File description: This file implements the conversion from a
//sensor witch return a value in int and we transform to analogic
//The objective is read a engineer value, not a computer value
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 19/05/23
//Revision Date: 25/05/23
//********************************************************//
#include "temperatureSensor.h"
#include "main.h"
#include "adc.h"

#define CONSTANT_OF_MULTIPLICATION 0.00079365

void vTemperatureSensorInit(ADC_HandleTypeDef *hadc){
	// ***************************************************** //
	//Method Name: vTemperatureSensorInit
	//Method Description: this function sets the calibration
	//of the adc and starts the DMA process
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	  HAL_ADCEx_Calibration_Start(hadc, ADC_SINGLE_ENDED);
	  HAL_ADC_Start_DMA(hadc,&uiValueFromDMA,1);
}


float fTemperatureSensorGetTemperature(){
	// ***************************************************** //
	//Method Name: fTemperatureSensorGetTemperature
	//Method Description: this function returns a value in float
	//that is the currently temperature of the sensor
	//
	//Input Params: n/a
	//
	//OutPut Params:float fMyTensao
	// ***************************************************** //
	unsigned int uiMyValue=uiValueFromDMA;
	float fMyTensao=CONSTANT_OF_MULTIPLICATION*(float)uiMyValue;
	fResistanceCurrently=fMyTensao*100;
	return fMyTensao*100;
}


