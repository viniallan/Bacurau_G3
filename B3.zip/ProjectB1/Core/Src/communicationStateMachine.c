//********************************************************//
//File name: communicationStateMachine.c
//File description: This file implements a state machine that 
//models the communication between computer and STM board. Creating
//a communication protocol.
//
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 28/04/23
//Revision Date: /04/23
//********************************************************//

#include <encoder.h>
#include "communicationStateMachine.h"
#include "main.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "heaterAndCooler.h"
#include "pid.h"


extern	float fResistanceCurrently;
extern 	float fResistanceSet;
extern uint32_t uiCurrentlyDutyCooler;
extern uint32_t uiCurrentlyDutyHeater;

#define IDDLE '0'
#define READY '1'
#define GET   '2'
#define GET_SECOND '3'
#define SET	  '4'
#define SET_SECOND '5'
#define PARAM  '6'
#define VALUE  '7'

#define MAX_VALUE_LENGHT '8'

unsigned char ucUartState =IDDLE;
unsigned char ucValueCount;

unsigned char ucMyWord[30];
unsigned char ucLineJump[]="\n";
unsigned char ucLineReturn[]="\r";
unsigned char ucSpace[]=" ";

void HAL_UART_RxCpltCallback(UART_HandleTypeDef * huart){
	// *************************************************************//
	//Method Name:HAL_UART_RxCpltCallback
	//Method Description: Interuption callback that deals with the 
	//complete reception of the message.
	//
	//Input Params: UART_HandleTypeDef* huart
	//
	//OutPut Params: n/a
	// ************************************************************ //
	if(huart == &hlpuart1){
		HAL_UART_Receive_IT(&hlpuart1, &c, 1);
		vCommunicationStateMachineProcessByteCommunication(c);
	}
}


void vCommunicationStateMachineProcessByteCommunication(unsigned char ucByte){
	// *************************************************************//
	//Method Name:vCommunicationStateMachineProcessByteCommunication
	//Method Description: This method implements the state machine, setting
	//the actual state and providing the next by user input.
	//
	//Input Params: unsigned char ucByte
	//
	//OutPut Params: n/a
	// ************************************************************ //
	if(ucByte!=13){
		HAL_UART_Transmit_IT(&hlpuart1, &ucByte, 1);
	}
	static unsigned char ucParam[2];
	static unsigned char ucValue[MAX_VALUE_LENGHT+1];
	if('#' == ucByte){
		ucUartState = READY;
	}
	else{
		if(IDDLE != ucUartState){
			switch(ucUartState){
				case READY:
					switch(ucByte){
						case 'g':
							ucUartState = GET;
							break;
						case 's':
							ucUartState = SET;
							break;
						default:
							ucUartState = IDDLE;
						}
					break;
				case GET:
					if('R' == ucByte || 'K' == ucByte || 'B' == ucByte || 'Z' == ucByte || 'C' == ucByte){
						ucParam[0] =ucByte;
						ucUartState= GET_SECOND;
					}
					else{
						ucUartState = IDDLE;
					}
					break;
				case GET_SECOND:
					if('C' == ucByte || 'S' == ucByte || 'M' == ucByte || 'D' == ucByte || 'm' == ucByte
							||'P' == ucByte || 'I' == ucByte || 'u' == ucByte || 'd' == ucByte || 'l' == ucByte
							||'r' == ucByte || 'e' == ucByte || 'f' == ucByte || 'V' == ucByte){
						ucParam[1] =ucByte;
						ucUartState= PARAM;
					}
					else{
						ucUartState = IDDLE;
					}
					break;
				case SET:
					if('R' == ucByte || 'K' == ucByte || 'B' == ucByte || 'Z' == ucByte || 'C' == ucByte){
						ucParam[0] =ucByte;
						ucUartState= SET_SECOND;
					}
					else{
						ucUartState = IDDLE;
					}
					break;
				case SET_SECOND:
					if('S' == ucByte || 'D' == ucByte || 'P' == ucByte || 'I' == ucByte || 'f' == ucByte){
						ucParam[1] =ucByte;
						ucValueCount=0;
						ucUartState= VALUE;
					}
					else{
						ucUartState = IDDLE;
					}
					break;
				case PARAM:
					if(';'==ucByte){
						HAL_UART_AbortTransmit(&hlpuart1);
						_write(&hlpuart1,";\n\r", 3);
						vCommunicationStateMachineReturnParam(ucParam);
					}
					ucUartState = IDDLE;
					break;
				case VALUE:
					if((ucByte>='0' && ucByte <= '9')|| ','==ucByte ||'.'==ucByte){
						if(ucValueCount<MAX_VALUE_LENGHT){
							ucValue[ucValueCount++]=ucByte;
						}
					}
					else{
						if(';'==ucByte){
							ucValue[ucValueCount]= '\0';
							vCommunicationStateMachineSetParam(ucParam, ucValue);
							HAL_UART_AbortTransmit(&hlpuart1);
							_write(&hlpuart1,";\n\r", 3);
						}
						ucUartState=IDDLE;
					}
					break;
			}
		}
	}

}
void vCommunicationStateMachineReturnParam(unsigned char* ucParam){
		// *************************************************************//
		//Method Name:vCommunicationStateMachineReturnParam
		//Method Description: Set wich parameter will be delivered to user when
		//a "get" command is given
		//
		//Input Params: unsigned char* ucParam
		//
		//OutPut Params: n/a
		// ************************************************************ //
	switch(ucParam[0]){
	case 'R':
		switch(ucParam[1]){
		case 'C':
			vCommunicationStateMachinePrintFloatValue(fResistanceCurrently);
		break;
		case 'S':
		break;
		case 'M':
		break;
		case 'D':
			vCommunicationStateMachinePrintFloatValue((float)uiCurrentlyDutyHeater/1000);
		break;
		case 'm':
		break;
		}
	break;
	case 'K':
		switch(ucParam[1]){
		case 'D':
			vCommunicationStateMachinePrintFloatValue(pid_getKd());
		break;
		case 'P':
			vCommunicationStateMachinePrintFloatValue(pid_getKp());
		break;
		case 'I':
			vCommunicationStateMachinePrintFloatValue(pid_getKi());
		break;
		}
	break;
	case 'B':
		switch(ucParam[1]){
		case 'S':
		break;
		case 'u':
		break;
		case 'd':
		break;
		case 'l':
		break;
		case 'r':
		break;
		case 'e':
		break;
		}
	break;
	case 'Z':
		switch(ucParam[1]){
		case 'S':
		break;
		case 'f':
		break;
		}
	break;
	case 'C':
		switch(ucParam[1]){
		case 'D':
			vCommunicationStateMachinePrintFloatValue((float)uiCurrentlyDutyCooler);
		break;
		case 'V':
			vCommunicationStateMachinePrintFloatValue((float)usiCoolerSpeed);
		break;
		}
	break;
	}
}

void vCommunicationStateMachinePrintUcValue(unsigned char ucValue){
	// *************************************************************//
	//Method Name:vCommunicationStateMachinePrintUcValue
	//Method Description: Print on putty screen an unsigned char value
	//based on a specific parameter
	//
	//Input Params: unsigned char ucValue
	//
	//OutPut Params: n/a
	// ************************************************************ //
	float fValue;
	for (int i=0;i<=255;i++){
		if(i==ucValue){
			fValue=(float)i;
		}
	}
	unsigned char ucStringValue[20];
	sprintf(ucStringValue,"%.0f",fValue);
	unsigned char ucWordToPrint[]="\n\r#a";
	unsigned char ucFinal[]=";\n\r";
	strcat(ucWordToPrint,ucStringValue);
	strcat(ucWordToPrint,ucFinal);
	int iSize=strlen(ucWordToPrint);
	HAL_UART_AbortTransmit(&hlpuart1);
	_write(&hlpuart1, ucWordToPrint, iSize);
}

void vCommunicationStateMachinePrintFloatValue(float fValue){
	// *************************************************************//
	//Method Name:vCommunicationStateMachinePrintFloatValue
	//Method Description: Print on putty screen a float value
	//based on a specific parameter
	//
	//Input Params: float fValue
	//
	//OutPut Params: n/a
	// ************************************************************ //
	unsigned char ucStringValue[20];
	sprintf(ucStringValue,"%.2f",fValue);
	unsigned char ucWordToPrint[]="\n\r#a";
	unsigned char ucFinal[]=";\n\r";
	strcat(ucWordToPrint,ucStringValue);
	strcat(ucWordToPrint,ucFinal);
	int iSize=strlen(ucWordToPrint);
	HAL_UART_AbortTransmit(&hlpuart1);
	_write(&hlpuart1, ucWordToPrint, iSize);
}

void vCommunicationStateMachineSetParam(unsigned char* ucParam, unsigned char* ucValue){
	// *************************************************************//
	//Method Name:vCommunicationStateMachineSetParam
	//Method Description: Define wich parameter will be set with the value inputed
	//based on the defined communication pattern
	//
	//Input Params: unsigned char* ucParam, unsigned char* ucValue
	//
	//OutPut Params: n/a
	// ************************************************************ //
	float fValue;
	switch(ucParam[0]){
		case 'R':
			switch(ucParam[1]){
			case 'C':
			break;
			case 'S':
				fResistanceSet=fCommunicationStateMachineConvertStringToFloat(ucValue);
			break;
			case 'M':
			break;
			case 'D':
			break;
			case 'm':
			break;
			}
		break;
		case 'K':
			switch(ucParam[1]){
			case 'D':
				fValue = fCommunicationStateMachineConvertStringToFloat(ucValue);
				pid_setKd(fValue);
			break;
			case 'P':
				fValue = fCommunicationStateMachineConvertStringToFloat(ucValue);
				pid_setKp(fValue);
			break;
			case 'I':
				fValue = fCommunicationStateMachineConvertStringToFloat(ucValue);
				pid_setKi(fValue);
			break;
			}
		break;
		case 'B':
			switch(ucParam[1]){
			case 'S':
			break;
			case 'u':
			break;
			case 'd':
			break;
			case 'l':
			break;
			case 'r':
			break;
			case 'e':
			break;
			}
		break;
		case 'Z':
			switch(ucParam[1]){
			case 'S':
			break;
			case 'f':
			break;
			}
		break;
		case 'C':
			switch(ucParam[1]){
			case 'D':
			break;
			case 'V':
			break;
			}
		break;
	}
}

float fCommunicationStateMachineConvertStringToFloat(unsigned char *ucString){
	// *************************************************************//
	//Method Name:fCommunicationStateMachineConvertStringToFloat
	//Method Description: Convert string value to float value
	//
	//Input Params: unsigned char *ucString
	//
	//OutPut Params: float fNewValue
	// ************************************************************ //
	int iSize=strlen(ucString);
	for(int i=0;i<=iSize;i++){
		if(ucString[i]==44){
			ucString[i]=46;
		}
	}
	float fNewValue=atof(ucString);
	return fNewValue;
}

unsigned char ucCommunicationStateMachineConvertUnsignedCharVectorToNumber(unsigned char *ucString){
	// *************************************************************//
	//Method Name:ucCommunicationStateMachineConvertUnsignedCharVectorToNumber
	//Method Description: Convert an unsigned char array to a number
	//
	//Input Params: unsigned char *ucString
	//
	//OutPut Params: unsigned char ucValue
	// ************************************************************ //
	float fMyFloat=atof(ucString);
	unsigned char ucValue=(unsigned char)fMyFloat;
	return ucValue;

}

