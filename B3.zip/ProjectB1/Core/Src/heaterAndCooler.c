//********************************************************//
//File name: heaterAndCooler.c
//File description: This file implements the heater and the 
//cooler handler.
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 12/05/23
//Revision Date: 16/05/23
//********************************************************//

#include "main.h"
#include "heaterAndCooler.h"
#include "tim.h"

uint32_t uiCurrentlyDutyCooler;
uint32_t uiCurrentlyDutyHeater;

void vHeaterAndCoolerInit(){
	// ***************************************************** //
	//Method Name: vHeaterAndCoolerInit
	//Method Description: Initialize pwm timers.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	HAL_TIM_PWM_Start_IT(&htim8, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start_IT(&htim1, TIM_CHANNEL_1);
}

void vHeaterAndCoolerCoolerfanPWMDuty(float fCoolerDuty){
	// ***************************************************** //
	//Method Name: vHeaterAndCoolerCoolerfanPWMDuty
	//Method Description: Set cooler duty cycle.
	//
	//Input Params: float fCoolerDuty
	//
	//OutPut Params: n/a
	// ***************************************************** //
	unsigned int uiCoolerDuty;
	if(fCoolerDuty>=1){
		uiCoolerDuty=1000;
	}
	else if(fCoolerDuty<=0){
	uiCoolerDuty=0;
	}
	else{
		uiCoolerDuty=(unsigned int)(1000*fCoolerDuty);
	}
	TIM8->CCR1=(uint32_t)uiCoolerDuty;
	uiCurrentlyDutyCooler=uiCoolerDuty;
}

void vHeaterAndCoolerStopCooler(){
	// ***************************************************** //
	//Method Name: vHeaterAndCoolerStopCooler
	//Method Description: Stop cooler, set its duty cycle to zero.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	TIM8->CCR1=0;
	uiCurrentlyDutyCooler=0;
}

void vHeaterAndCoolerHeaterPWMDuty(float fHeaterDuty){
	// ***************************************************** //
	//Method Name: vHeaterAndCoolerHeaterPWMDuty
	//Method Description: Set Heater duty cycle.
	//
	//Input Params: float fHeaterDuty
	//
	//OutPut Params: n/a
	// ***************************************************** //
	unsigned int uiHeaterDuty;
	if(fHeaterDuty>=1){
		uiHeaterDuty=1000;
	}
	else if(fHeaterDuty<=0){
	uiHeaterDuty=0;
	}
	else{
		uiHeaterDuty=(unsigned int)(1000*fHeaterDuty);
	}
	TIM1->CCR1=(uint32_t)uiHeaterDuty;
	uiCurrentlyDutyHeater=uiHeaterDuty;
}

void vHeaterAndCoolerStopHeater(){
	// ***************************************************** //
	//Method Name: vHeaterAndCoolerStopHeater
	//Method Description: Stop heater, set its duty cycle to zero.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	TIM1->CCR1=0;
	uiCurrentlyDutyCooler=0;
}

void vHeadAndCoolerIncrise10DutyCooler(){
	// ***************************************************** //
	//Method Name: vHeadAndCoolerIncrise10DutyCooler
	//Method Description: Increase cooler duty cycle.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(uiCurrentlyDutyCooler<=900){
		uiCurrentlyDutyCooler=uiCurrentlyDutyCooler+100;
		vHeaterAndCoolerCoolerfanPWMDuty((float)uiCurrentlyDutyCooler/1000);
	}
	else{
		uiCurrentlyDutyCooler=1000;
		vHeaterAndCoolerCoolerfanPWMDuty(1);
	}
}

void vHeadAndCoolerIncrise10DutyHeater(){
	// ***************************************************** //
	//Method Name: vHeadAndCoolerIncrise10DutyHeater
	//Method Description: Increase heater duty cycle.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(uiCurrentlyDutyHeater<=900){
		uiCurrentlyDutyHeater=uiCurrentlyDutyHeater+100;
		vHeaterAndCoolerHeaterPWMDuty((float)uiCurrentlyDutyHeater/1000);
	}
	else{
		uiCurrentlyDutyHeater=1000;
		vHeaterAndCoolerHeaterPWMDuty(1);
	}
}

void vHeadAndCoolerDecrise10DutyCooler(){
	// ***************************************************** //
	//Method Name: vHeadAndCoolerDecrise10DutyCooler
	//Method Description: Decrease cooler duty cycle.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(uiCurrentlyDutyCooler>100){
		uiCurrentlyDutyCooler=uiCurrentlyDutyCooler-100;
		vHeaterAndCoolerCoolerfanPWMDuty((float)uiCurrentlyDutyCooler/1000);
	}
	else{
		uiCurrentlyDutyCooler=0;
		vHeaterAndCoolerCoolerfanPWMDuty(0);
	}
}

void vHeadAndCoolerDecrise10DutyHeater(){
	// ***************************************************** //
	//Method Name: vHeadAndCoolerDecrise10DutyHeater
	//Method Description: Decrease heater duty cycle.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(uiCurrentlyDutyHeater>100){
		uiCurrentlyDutyHeater=uiCurrentlyDutyHeater-100;
		vHeaterAndCoolerHeaterPWMDuty((float)uiCurrentlyDutyHeater/1000);
	}
	else{
		uiCurrentlyDutyHeater=0;
		vHeaterAndCoolerHeaterPWMDuty(0);
	}
}
