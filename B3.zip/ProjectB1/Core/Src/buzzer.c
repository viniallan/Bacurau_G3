//********************************************************//
//File name: buzzer.c
//File description: This file implements the buzzer handler.
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 12/05/23
//Revision Date: 16/05/23
//********************************************************//


#include "main.h"
#include "buzzer.h"
#include "tim.h"

unsigned short int usiBuzzerFrequency;
unsigned short int usiBuzzerPeriod;
unsigned int uiBuzzerCounterTime;

void vBuzzerInit(){
	// ***************************************************** //
	//Method Name: vBuzzerInit
	//Method Description: Initialize the buzzer pwm timer and counter.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	HAL_TIM_PWM_Start_IT(&htim20, TIM_CHANNEL_1);
	TIM20->CCR1=(uint32_t)0;
	uiBuzzerCounterTime=0;
}

 void vBuzzerConfig(unsigned short int usiFrequency, unsigned short int usiPeriod){
	// ***************************************************** //
	//Method Name: vBuzzerConfig
	//Method Description: Set buzzer frequency and period.
	//
	//Input Params: unsigned short int usiFrequency, unsigned short int usiPeriod
	//
	//OutPut Params: n/a
	// ***************************************************** //
	 usiBuzzerFrequency=usiFrequency;
	 usiBuzzerPeriod=usiPeriod;
 }

 void vBuzzerPlay(){
	// ***************************************************** //
	//Method Name: vBuzzerPlay
	//Method Description: Play buzzer.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	 int iARR=(1000000)/usiBuzzerFrequency;

	 TIM20->ARR=(uint32_t)iARR;
	 TIM20->CCR1=(uint32_t)iARR/2;
	 HAL_TIM_Base_Start_IT(&htim5);
 }

void vBuzzerCallback(){
	// ***************************************************** //
	//Method Name: vBuzzerCallback
	//Method Description: Deals with the buzzer interuption.
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	if(uiBuzzerCounterTime>=usiBuzzerPeriod){
		HAL_TIM_Base_Stop_IT(&htim5);
		TIM20->CCR1=(uint32_t)0;
		uiBuzzerCounterTime=0;
	}
	else{
		uiBuzzerCounterTime++;
	}
 }



