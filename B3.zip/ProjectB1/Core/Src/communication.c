//********************************************************//
//File name: communication.h
//File description: This file implements the some functions
// 					to exchange date with the Putty Terminal
// 					there are some function that do the call
//					back logic and function that does the
//  				comparation beetween the numbers limits
//
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 23/04/23
//Revision Date: 27/04/23
//********************************************************//
#include "main.h"
#include "communication.h"
#include "light_printf.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern UART_HandleTypeDef hlpuart1;

char cWordDefault[]="\n\rNúmero fora do intervalo!\n\r";
char cLineJump[]="\n";
char cLineReturn[]="\r";
char cSpace[]=" ";
int iSize=0;
int iIndice=0;
char cMyWord[30];
float fMyFloat;

// *************************************************************//
//Method Name:vCommunicationCallback
//Method Description:this method does the most important part to
//					exchange data beetween the putty and STM
//					it'll receive a char c, check if the isn't
//					the termination or a dot and add to a char
//					vector. After that, convert it to a float and
//					check if it is in the interval, if it were,
//					reply the inversal and trhough it to Putty.
//
//Input Params: char c
//
//OutPut Params: n/a
// ************************************************************ //
void vCommunicationCallback(char c){
	if(c!=13){
		if(c==44){
			cMyWord[iIndice]=46;

		}else{
			cMyWord[iIndice]=c;
		}
		iIndice++;
		HAL_UART_Transmit_IT(&hlpuart1, &c, 1);
	}
	else{
		cMyWord[iIndice]=cLineJump;
		strcat(cMyWord,cSpace);
		iIndice=0;
		fMyFloat=atof(cMyWord);
	    if(iCommunicationCheckBeetwen2ThousandReturnInverse(fMyFloat)==FALSE){
	    	iSize=strlen(cWordDefault);
	    	_write(&hlpuart1, cWordDefault, iSize);
	    }else{
	    	fMyFloat=1/fMyFloat;
	    	sprintf(cMyWord,"\n\r%f",fMyFloat);
	        int iLenght=strlen(cMyWord);
	        int iVarCounter=0;
	        for (int i=0;i<=iLenght;i++){
	        	if((iVarCounter<5)&(iVarCounter>=1)){
	        		iVarCounter++;
	        	}
	        	if(cMyWord[i]==46){
	        		cMyWord[i]=44;
	        		iVarCounter=1;
	        	}
	        	if(iVarCounter>=5){
	        		cMyWord[i]=0;
	        	}
	        }
	        //iSize=strlen(cLineJump);
	        //_write(&hlpuart1, cLineJump, iSize); //tentativa de pular linha na resposta
			strcat(cMyWord,cLineJump);
			strcat(cMyWord,cLineReturn);
	    	iSize=strlen(cMyWord);
	        _write(&hlpuart1, cMyWord, iSize);
	    }
	}
}


// *************************************************************//
//Method Name:iCommunicationCheckBeetwen2ThousandReturnInverse
//Method Description:this method checks if the number gotten from
//					the putty terminal is beetween the edges.
//					return TRUE if it were real and FALSE case not
//
//Input Params: float fNumber
//
//OutPut Params: int TRUE or FALSE
// ************************************************************ //
int iCommunicationCheckBeetwen2ThousandReturnInverse(float fNumber){
    if((fNumber<=1000) & (fNumber>=-1000)){
        return TRUE;
    }else{
        return FALSE;
    }
}


