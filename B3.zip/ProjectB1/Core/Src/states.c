//********************************************************//
//File name: States.c
//File description: this file aims to provid the background
//of the system to the project, so, there will be function that
//does the logical to flip beetween the menssagens, change the state
//and initialize all the things
//
//Author Name: Vinicius Allan da Silva RA:225295
//			   João Vitor Crotti Figueiredo RA:199883
//Creation Date: 26/05/23
//Revision Date: 07/06/23
//********************************************************//

#include <encoder.h>
#include "states.h"
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "usart.h"
#include "tim.h"
#include "gpio.h"

#include "main.h"
#include "led.h"
#include "communication.h"
#include "lcd.h"
#include "heaterAndCooler.h"
#include "buzzer.h"
#include "temperatureSensor.h"
#include "pid.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

unsigned char ucState;
unsigned char ucStateGainButton;

int iTimer;
char cWordMenu[20];
char cWordMenuAux[20];





void vStatesLoop(){
	// ***************************************************** //
	//Method Name: 	vStatesLoop
	//Method Description: this method aims to plot in display, based on the
	//currently state
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //


	// set the cursor line 0, column 1
	vLcdSetCursor(0,0);
	sprintf(cWordMenu,"%.2f<-Temp.",fResistanceCurrently);
	vLcdWriteString(cWordMenu);
	// set the cursor line 0, column 1
	vLcdSetCursor(1,0);

	// variable for better displaying
	float fCurrentlyDutyHeaterToDisplay;
	float fCurrentlyCoolerSpeed;

	// send string
	switch(ucState){

	case STATEKP:
		sprintf(cWordMenu,"%.2f<-Kp        ",pid_getKp());
		vLcdWriteString(cWordMenu);
	break;
	case STATEKI:
		sprintf(cWordMenu,"%.2f<-Ki        ",pid_getKi());
		vLcdWriteString(cWordMenu);
	break;
	case STATEKD:
		sprintf(cWordMenu,"%.2f<-Kd        ",pid_getKd());
		vLcdWriteString(cWordMenu);
	break;
	case STATECOOLERSPEED:
		fCurrentlyCoolerSpeed = (float)usiCoolerSpeed;
		sprintf(cWordMenu,"%.0f<-Tachom.  ",fCurrentlyCoolerSpeed);
		vLcdWriteString(cWordMenu);
	break;
	case STATECURRENTLYSETPOINT:
		sprintf(cWordMenu,"%.2f<-Set P.   ",fResistanceSet);
		vLcdWriteString(cWordMenu);
	break;
	case STATECURRENTLYDUTYCICLER:
		fCurrentlyDutyHeaterToDisplay = (float)uiCurrentlyDutyHeater/1000;
		sprintf(cWordMenu,"%.2f<-Heater D C",fCurrentlyDutyHeaterToDisplay);
		vLcdWriteString(cWordMenu);
	break;
	}



}

void vStatesTimerCallback(){
	// ***************************************************** //
	//Method Name: 	vStatesTimerCallback
	//Method Description: this method aims to counter util 1500ms
	//the interruption call this function for each 10ms
	//when this function is called, the state change to the next
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //

	//
	if(iTimer>=300){
		iTimer=0;
		vStatesNextState();
	}
	else{
		iTimer++;
	}
}

void vStatesNextState(){
	// ***************************************************** //
	//Method Name: 	vStatesNextState
	//Method Description: this method aims change the currently
	//state to the next
	//
	//Input Params: n/a
	//
	//OutPut Params: n/a
	// ***************************************************** //
	switch(ucState){
	case STATEKP:
		ucState=STATEKI;
	break;
	case STATEKI:
		ucState=STATEKD;
	break;
	case STATEKD:
		ucState=STATECOOLERSPEED;
	break;
	case STATECOOLERSPEED:
		ucState=STATECURRENTLYSETPOINT;
	break;
	case STATECURRENTLYSETPOINT:
		ucState=STATECURRENTLYDUTYCICLER;
	break;
	case STATECURRENTLYDUTYCICLER:
		ucState=STATEKP;
	break;
	}
}

int vStatesChangeGainButton(){
	if(ucStateGainButton==0){
		ucStateGainButton=1;
		return 1;
	}
	else if(ucStateGainButton==1){
		ucStateGainButton=2;
		return 2;
	}
	else if(ucStateGainButton==2){
		ucStateGainButton=0;
		return 0;
	}
}

void vStatesSetState(unsigned char ucNewState){
	ucState=ucNewState;
}

unsigned char ucStatesReturnState(){
	return ucState;
}

unsigned char ucStatesReturnStateButtonGain(){
	return ucStateGainButton;
}

void vStatesCleanCounter(){
	iTimer=0;
}
